const test = require("node:test");
const assert = require("node:assert");
const { add, subtract, multiply, divide, isEven } = require("./calculator");

test("add", () => {
  assert.strictEqual(add(2, 3), 5);
  assert.strictEqual(add(-1, 1), 0);
});

test("subtract", () => {
  assert.strictEqual(subtract(5, 1), 4);
  assert.strictEqual(subtract(0, 5), -5);
});

test("multiply", () => {
  assert.strictEqual(multiply(4, 6), 24);
  assert.strictEqual(multiply(-2, 3), -6);
});

test("divide", () => {
  assert.strictEqual(divide(10, 2), 5);
  assert.throws(() => divide(10, 0), Error);
});

test("isEven", () => {
  assert.strictEqual(isEven(4), true);
  assert.strictEqual(isEven(7), false);
});
