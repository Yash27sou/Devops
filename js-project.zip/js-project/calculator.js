// A tiny calculator module — simple example for a GitHub + Travis CI project.

function add(a, b) {
  return a + b;
}

function subtract(a, b) {
  return a - b;
}

function multiply(a, b) {
  return a * b;
}

function divide(a, b) {
  if (b === 0) {
    throw new Error("Cannot divide by zero");
  }
  return a / b;
}

function isEven(n) {
  return n % 2 === 0;
}

module.exports = { add, subtract, multiply, divide, isEven };

if (require.main === module) {
  console.log("2 + 3 =", add(2, 3));
  console.log("5 - 1 =", subtract(5, 1));
  console.log("4 * 6 =", multiply(4, 6));
  console.log("10 / 2 =", divide(10, 2));
}
