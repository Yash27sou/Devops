# JS Calculator (Travis CI demo)

[![Build Status](https://app.travis-ci.com/USER/REPO.svg?branch=main)](https://app.travis-ci.com/USER/REPO)

A minimal Node.js project with a test suite (using Node's built-in test runner — no dependencies needed), ready to push to GitHub and hook up to Travis CI.

## Run locally

```bash
node calculator.js
npm test
```

## Files

- `calculator.js` — the module (add, subtract, multiply, divide, isEven)
- `calculator.test.js` — test suite (`node:test` + `node:assert`, built into Node 18+)
- `package.json` — defines `npm test` → `node --test`
- `.travis.yml` — Travis CI config (runs `npm test` on Node 18 and 20)
